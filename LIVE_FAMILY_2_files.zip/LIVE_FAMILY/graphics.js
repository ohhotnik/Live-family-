/* LIVE FAMILY — graphics engine (offline, no external images) */
(() => {
'use strict';
const G = window.LFGraphics = {};
const TILE = 64;
const palette = {
  grass:'#5d9b55', grass2:'#6cab5b', road:'#454852', roadLine:'#e9d88a',
  sidewalk:'#b9b7ad', wall:'#e8c99a', roof:'#9d4b54', roof2:'#674a9b'
};
function rect(c,x,y,w,h,color){c.fillStyle=color;c.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
function outline(c,x,y,w,h,color='#27243a',lw=2){c.strokeStyle=color;c.lineWidth=lw;c.strokeRect(x,y,w,h);}
function rounded(c,x,y,w,h,r,color){c.fillStyle=color;c.beginPath();c.roundRect(x,y,w,h,r);c.fill();}
function tree(c,x,y,s=1){
  c.fillStyle='#493b2d';c.fillRect(x-4*s,y+9*s,8*s,18*s);
  c.fillStyle='#245d3c';c.beginPath();c.arc(x,y,17*s,0,Math.PI*2);c.fill();
  c.fillStyle='#3d8a4d';c.beginPath();c.arc(x-7*s,y-6*s,10*s,0,Math.PI*2);c.fill();
  c.fillStyle='#75b85c';c.fillRect(x-9*s,y-12*s,5*s,4*s);
}
function car(c,x,y,color='#d84c55',scale=1){
  c.save();c.translate(x,y);c.scale(scale,scale);
  rounded(c,-23, -12,46,25,6,'#20232d');rounded(c,-20,-14,40,23,5,color);
  rounded(c,-10,-11,20,12,3,'#a9d9e8');rect(c,-8,-10,2,10,'#577f99');
  rect(c,-18,-7,4,7,'#fff0b5');rect(c,14,-7,4,7,'#fff0b5');
  rect(c,-15,9,8,4,'#292a32');rect(c,8,9,8,4,'#292a32');
  c.restore();
}
function building(c,b){
  const {x,y,w,h,type='house',color='#e7bd8c',roof='#a54f56'}=b;
  // shadow and foundation
  rect(c,x+8,y+10,w,h,'#34443a');rect(c,x,y,w,h,'#c9b28f');
  if(type==='shop'||type==='cafe'){
    rect(c,x+4,y+4,w-8,h-8,'#f1d6a8');rect(c,x+4,y+4,w-8,17,'#9d4354');
    rect(c,x+12,y+28,w-24,25,'#79b8c8');outline(c,x+12,y+28,w-24,25);
    rect(c,x+8,y+h-22,w-16,14,'#e9a54c');
    c.fillStyle='#fff';c.font='bold 10px Arial';c.fillText(type==='cafe'?'CAFE':'MARKET',x+10,y+15);
  } else if(type==='hospital'){
    rect(c,x+4,y+4,w-8,h-8,'#f2eee8');rect(c,x+10,y+12,w-20,20,'#8cb8c9');
    rect(c,x+w/2-4,y+17,8,24,'#fff');rect(c,x+w/2-12,y+25,24,8,'#d84d5c');
    rect(c,x+12,y+43,w-24,22,'#a9d2dc');outline(c,x+12,y+43,w-24,22);
    rect(c,x+w/2-12,y+h-24,24,24,'#74506b');
  } else {
    rect(c,x+4,y+4,w-8,h-8,color);
    // roof with tile rows
    rect(c,x-3,y-7,w+6,24,roof);outline(c,x-3,y-7,w+6,24,'#453344',2);
    for(let xx=x+3;xx<x+w;xx+=18) rect(c,xx,y-5,2,20,'#ffffff22');
    // windows
    const winY=y+32;
    for(let xx=x+12;xx<x+w-10;xx+=Math.max(26,(w-24)/2)){
      rect(c,xx,winY,15,18,'#83c3d4');outline(c,xx,winY,15,18);
      rect(c,xx+6,winY,2,18,'#e9e4d3');
    }
    rect(c,x+w/2-10,y+h-28,20,28,'#775044');rect(c,x+w/2-6,y+h-24,12,10,'#c7a16c');
  }
  outline(c,x,y,w,h,'#443a3d',2);
}
function person(c,x,y,shirt='#7d55d9',hair='#4c302b',scale=1,step=0){
  c.save();c.translate(x,y);c.scale(scale,scale);
  // shadow
  c.fillStyle='#26352d66';c.beginPath();c.ellipse(0,12,10,4,0,0,Math.PI*2);c.fill();
  rect(c,-6,1,5,10,'#39435a');rect(c,2,1,5,10,'#39435a');
  rect(c,-8,-9,16,13,shirt);rect(c,-9,-7,4,9,shirt);rect(c,5,-7,4,9,shirt);
  c.fillStyle='#f1c49c';c.beginPath();c.arc(0,-15,8,0,Math.PI*2);c.fill();
  rect(c,-8,-21,16,7,hair);rect(c,-8,-17,3,5,hair);
  rect(c,-3,-16,2,2,'#302a31');rect(c,4,-16,2,2,'#302a31');
  c.restore();
}
function drawWorld(ctx, camera, state){
  const c=ctx, W=state.width, H=state.height, t=state.time||0;
  c.save();c.translate(-camera.x,-camera.y);
  // grass ground tile pattern
  rect(c,0,0,W,H,palette.grass);
  for(let y=0;y<H;y+=64)for(let x=0;x<W;x+=64){
    if(((x/64+y/64)%3)===0)rect(c,x+8,y+12,3,3,'#78b966');
    if(((x/64+y/64)%4)===0)rect(c,x+43,y+39,2,2,'#397e4a');
  }
  // city blocks and road network
  rect(c,0,350,W,116,palette.road);rect(c,0,397,W,3,'#555b65');
  rect(c,0,350,W,5,'#777b82');rect(c,0,456,W,5,'#777b82');
  for(let x=20;x<W;x+=90)rect(c,x,405,42,4,palette.roadLine);
  rect(c,570,0,116,350,palette.road);rect(c,625,0,4,350,'#555b65');
  for(let y=12;y<340;y+=80)rect(c,625,y,4,36,palette.roadLine);
  // sidewalks
  rect(c,0,334,W,16,palette.sidewalk);rect(c,0,466,W,16,palette.sidewalk);
  rect(c,554,0,16,350,palette.sidewalk);rect(c,686,0,16,350,palette.sidewalk);
  // park
  rounded(c,40,40,250,245,18,'#78b96b');outline(c,40,40,250,245,'#d4d0a5',4);
  for(let i=0;i<9;i++)tree(c,75+(i%3)*78,80+Math.floor(i/3)*72,.8+(i%2)*.1);
  rounded(c,150,150,75,22,8,'#d9c39a');rect(c,180,151,7,20,'#89684c');
  // buildings
  const buildings=[
    {x:330,y:55,w:165,h:220,color:'#e7c89a',roof:'#a84d58'},
    {x:735,y:60,w:180,h:170,color:'#d6b5df',roof:'#6d5a9b'},
    {x:980,y:60,w:150,h:180,color:'#d8c39d',roof:'#a75b49'},
    {x:330,y:505,w:180,h:155,color:'#b9d5d2',roof:'#537c83'},
    {x:745,y:510,w:180,h:155,type:'shop'},
    {x:980,y:505,w:165,h:155,type:'hospital'}
  ];
  buildings.forEach(b=>building(c,b));
  // street objects
  car(c,125,405,'#d94f5b',1.05);car(c,800,405,'#4d8cc8',1.05);
  car(c,625,285,'#e5b44f',.95);
  // benches, lamps, bins
  for(const x of [300,520,720,940]){
    rect(c,x,326,5,27,'#4a4a53');rounded(c,x-9,319,24,8,3,'#80583f');
    rect(c,x+3,300,3,22,'#4a4a53');c.fillStyle='#f7e7a1';c.beginPath();c.arc(x+4,298,6,0,Math.PI*2);c.fill();
  }
  // decorative flower beds
  for(const x of [300,520,720,940]){rounded(c,x,480,46,12,5,'#477b48');for(let k=0;k<5;k++){c.fillStyle=['#f2c3df','#fff0a4','#c6b4ff'][k%3];c.beginPath();c.arc(x+5+k*9,484,3,0,7);c.fill();}}
  // NPCs
  person(c,210,310,'#f0a04a','#5a3328',1,.2);person(c,530,305,'#4d92c7','#342c2c',1,.4);
  person(c,875,300,'#d86a91','#513b31',1,.7);person(c,1080,470,'#5caa70','#302c28',1,.1);
  // player
  person(c,state.player.x,state.player.y,state.player.shirt||'#8255dc',state.player.hair||'#4b302c',1,Math.sin(t/100)*2);
  c.restore();
}
function drawInterior(ctx, state){
  const c=ctx,W=state.width,H=state.height;
  rect(c,0,0,W,H,'#9a765b');
  // wooden floorboards
  rect(c,0,0,W,H,'#b98c67');
  for(let y=0;y<H;y+=42){rect(c,0,y,W,2,'#8f674f');for(let x=(y%84?25:0);x<W;x+=130)rect(c,x,y,2,42,'#a47758');}
  // walls and skirting
  rect(c,0,0,W,55,'#ead9c4');rect(c,0,55,W,8,'#f4e9d8');
  // rug
  rounded(c,290,155,360,220,18,'#654c91');rounded(c,303,168,334,194,12,'#b89ad2');
  for(let x=320;x<630;x+=30)rect(c,x,180,2,170,'#d7c3e7');
  // sofa
  rounded(c,70,100,185,90,16,'#567d9a');rounded(c,82,110,160,65,12,'#7fa7bb');
  rect(c,83,180,155,12,'#3c6077');rounded(c,91,118,60,45,8,'#9bc1ce');rounded(c,160,118,65,45,8,'#9bc1ce');
  // table
  rounded(c,380,235,170,78,12,'#8a583e');rect(c,395,305,8,30,'#65402f');rect(c,525,305,8,30,'#65402f');
  rounded(c,430,250,65,28,7,'#f1d4a2');
  // kitchen
  rect(c,780,70,190,75,'#d6dce0');rect(c,780,145,190,12,'#7d8990');
  for(let x=795;x<960;x+=55){rect(c,x,83,43,48,'#f5f3eb');outline(c,x,83,43,48);rect(c,x+17,92,8,5,'#9faab0');}
  rect(c,820,175,130,100,'#e7e1d7');rect(c,835,190,100,60,'#9ec8d4');outline(c,835,190,100,60);
  // bed
  rounded(c,760,350,205,145,14,'#634b79');rounded(c,770,360,185,118,10,'#e7e1e8');
  rounded(c,785,370,70,38,7,'#fff');rounded(c,865,370,70,38,7,'#fff');rect(c,775,420,180,55,'#b9a4d4');
  // window and plant
  rect(c,390,70,130,75,'#79b9d1');outline(c,390,70,130,75,'#fff',5);rect(c,452,70,4,75,'#fff');rect(c,390,105,130,4,'#fff');
  tree(c,680,125,.9);
  // door
  rect(c,40,320,90,170,'#76503c');outline(c,40,320,90,170,'#3c2c2a',4);rect(c,108,400,7,7,'#e8c56a');
  person(c,state.player.x,state.player.y,state.player.shirt||'#8255dc',state.player.hair||'#4b302c',1,0);
}
G.draw=(ctx,camera,state)=>{ if(state.inside)drawInterior(ctx,state);else drawWorld(ctx,camera,state); };
})();
